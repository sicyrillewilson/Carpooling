@file:Suppress("DEPRECATION")

package tg.eplcoursandroid.carpooling

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import tg.eplcoursandroid.carpooling.databinding.SignInBinding
import tg.eplcoursandroid.carpooling.models.Passager
import tg.eplcoursandroid.carpooling.models.Utilisateur
import tg.eplcoursandroid.carpooling.service.AuthService
import tg.eplcoursandroid.carpooling.service.ConducteurService
import tg.eplcoursandroid.carpooling.service.PassagerService
import tg.eplcoursandroid.carpooling.service.UtilisateurService

/*import android.app.ProgressDialog
import android.content.Intent
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import com.example.chatmessenger.MainActivity
import com.example.chatmessenger.R
import com.example.chatmessenger.databinding.ActivitySignInBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException*/

class SignInActivity : AppCompatActivity() {

    /*private lateinit var goToSignUpActivity : TextView
    private lateinit var email : String
    private lateinit var password : String
    private lateinit var auth : FirebaseAuth
    private lateinit var progressDialogSignIn : ProgressDialog
    private lateinit var signinInBinding : SignInBinding*/

    lateinit var name: String
    lateinit var email: String
    lateinit var password: String
    lateinit private var fbauth: FirebaseAuth
    lateinit private var pds: ProgressDialog
    lateinit var binding : SignInBinding

    private val authService = AuthService()
    private val passagerService = PassagerService()
    private val utilisateurService = UtilisateurService()
    private val conducteurService = ConducteurService()

    // Ajout de la variable pour suivre l'état du mot de passe
    private var isPasswordVisible = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.sign_in)
        binding = SignInBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setTitle(localClassName)

        enableEdgeToEdge()

        fbauth = FirebaseAuth.getInstance()
        if (fbauth.currentUser!=null){
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
        pds = ProgressDialog(this)

        togglePasswordVisibility()

        // Clic sur l'icône pour afficher/masquer le mot de passe
        binding.passwordToggle.setOnClickListener {
            togglePasswordVisibility()
            // Mettre à jour l'état de la visibilité
            isPasswordVisible = !isPasswordVisible
            // Re-donner le focus à l'EditText pour que le texte apparaisse immédiatement
            binding.signInMotDePasse.setSelection(binding.signInMotDePasse.text.length)
        }

        binding.signInCreerCompte.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
            finish()
        }
        binding.signInConnexion.setOnClickListener {
            email = binding.signInEmail.text.toString()
            password = binding.signInMotDePasse.text.toString()
            if (binding.signInEmail.text.isEmpty()){
                Toast.makeText(this, "Entrer votre email", Toast.LENGTH_SHORT).show()
            }
            if (binding.signInMotDePasse.text.isEmpty()){
                Toast.makeText(this, "Enter votre mot de passe", Toast.LENGTH_SHORT).show()
            }
            if (binding.signInEmail.text.isNotEmpty() && binding.signInMotDePasse.text.isNotEmpty()){
                signIn(password, email)
            }
        }
    }

    private fun togglePasswordVisibility() {
        val typeface = binding.signInMotDePasse.typeface // Sauvegarde la police

        if (isPasswordVisible) {
            // Masquer le mot de passe
            binding.signInMotDePasse.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            binding.passwordToggle.setImageResource(R.drawable.eye)

        } else {
            // Afficher le mot de passe
            binding.signInMotDePasse.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            binding.passwordToggle.setImageResource(R.drawable.hidden)

        }

        // Réappliquer la police
        binding.signInMotDePasse.typeface = typeface
    }

    private fun signIn(password: String, email: String) {
        pds.show()
        pds.setMessage("Connexion en cours")
        authService.connecter(email, password) { success, message ->
            if (success) {
                Log.d("Inscrire", "rahim connecte")
                pds.dismiss()
                //startActivity(Intent(this, MainActivity::class.java))
                val intent = Intent(this, MainActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            } else {
                Log.d("Inscrire", "rahim non connecte")
                pds.dismiss()
                Toast.makeText(applicationContext, "Données invalides", Toast.LENGTH_SHORT).show()
            }
        }

        /*fbauth.signInWithEmailAndPassword(email, password).addOnCompleteListener {
            if (it.isSuccessful){
                pds.dismiss()
                startActivity(Intent(this, MainActivity::class.java))
            } else {
                pds.dismiss()
                Toast.makeText(applicationContext, "Données invalides", Toast.LENGTH_SHORT).show()
            }
        }.addOnFailureListener {exception->
            when (exception){
                is FirebaseAuthInvalidCredentialsException ->{
                    Toast.makeText(applicationContext, "Données invalides", Toast.LENGTH_SHORT).show()
                }
                else-> {
                    // other exceptions
                    Toast.makeText(applicationContext, "Authentification échouée", Toast.LENGTH_SHORT).show()
                }
            }
        }*/
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        pds.dismiss()
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        pds.dismiss()

    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    )
        }
    }
}